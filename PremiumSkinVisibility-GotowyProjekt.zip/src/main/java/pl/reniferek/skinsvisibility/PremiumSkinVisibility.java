package pl.reniferek.skinsvisibility;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class PremiumSkinVisibility extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("PremiumSkinVisibility wlaczony.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        getLogger().info("Gracz dolaczyl: " + player.getName());
    }

    public boolean isPremium(Player player) {
        if (player.hasPermission("psv.premium")) return true;
        if (player.hasPermission("psv.nopremium")) return false;
        return Bukkit.getOnlineMode();
    }
}
